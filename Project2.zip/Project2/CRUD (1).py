#Paul Gardner
#
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        #initialize MongoClient
        self.client = MongoClient('mongodb://%s:%s@127.0.0.1:41443/?authMechanism=DEFAULT&authSource=AAC' % 
        (username, password))
        self.database = self.client['AAC']

    #method to impliment C in CRUD
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) #data should be dictionary
            return True
        else:
            raise Exception("nothing to create, because data parameter is empty")
            return False

    #method to impliment R in Crud
    def read(self, readData):
        if readData:      
            query = self.database.animals.find(readData,{"_id":False})
        else:  
            query = self.database.animals.find( {} , {"_id":False})

        return query
        
    #method to impliment U in Crud
    def update(self, save):
        if save is not None:
        # update if id_property true, else make new
            if save:
                saveResult = self.database.animals.insert_one(save)
                return saveResult
        else:
            exception = "Nothing to update, because save parameter is None"
            
    #method to impliment D in Crud
    def delete(self, remove):
        if remove is not None:
            if remove:
                removeResult = self.database.animals.delete_one(remove)
        else:
            exception: "Nothing to delete, because remove parameter is None"